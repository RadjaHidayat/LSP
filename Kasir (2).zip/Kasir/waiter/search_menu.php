<?php
$koneksi = mysqli_connect("localhost", "root", "", "restoran");
if (mysqli_connect_errno()) {
    echo "Koneksi database gagal: " . mysqli_connect_error();
    exit();
}

$cari = $_POST['cari'];

$query = "SELECT p.id_pesanan, m.namamenu, m.harga 
          FROM pesanan p
          JOIN menu m ON p.id_menu = m.id_menu
          WHERE m.namamenu LIKE '%$cari%'";
$result = mysqli_query($koneksi, $query);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        echo '<td>' . $row['idtransaksi'] . '</td>';
        echo '<td>' . $row['id_pesanan'] . '</td>';
        echo '<td>' . $row['namamenu'] . '</td>';
        echo '<td>Rp. ' . $row['harga'] . '</td>';
        echo '<td><button class="btn btn-primary tambah-ke-kasir" data-id-pesanan="' . $row['id_pesanan'] . '" data-nama="' . $row['namamenu'] . '" data-harga="' . $row['harga'] . '">Tambah ke Kasir</button></td>';
        echo '</tr>';
    }
} else {
    echo "<tr><td colspan='4'>Tidak ada hasil ditemukan.</td></tr>";
}

mysqli_close($koneksi);
?>
