<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Kasir Go</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        /* Your custom styles here */

        /* Adjustments for smaller screens */
        @media (max-width: 768px) {
            /* Add your responsive styles here */
        }
    </style>
</head>

<body id="page-top">
    <!-- Include sidebar and navbar templates here -->
    <?php include 'template/sidebar.php'; ?>
    <?php include 'template/navbar.php'; ?>

    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">
            <div class="container-fluid">
                <h4>Keranjang Penjualan</h4>
                <!-- Alerts for success and removal -->
                <?php if (isset ($_GET['success'])) { ?>
                    <div class="alert alert-success">
                        <p>Edit Data Berhasil !</p>
                    </div>
                <?php } ?>
                <?php if (isset ($_GET['remove'])) { ?>
                    <div class="alert alert-danger">
                        <p>Hapus Data Berhasil !</p>
                    </div>
                <?php } ?>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="card card-primary mb-3">
                                <div class="card-header bg-primary text-white">
                                    <h5><i class="fa fa-search"></i> Cari Barang</h5>
                                </div>
                                <div class="card-body">
                                    <input type="text" id="cari" class="form-control" name="cari"
                                        placeholder="Masukan : Kode / Nama Barang  [ENTER]">
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <!-- Search Results -->
                            <div class="card card-primary mb-3">
                                <div class="card-header bg-primary text-white">
                                    <h5><i class="fa fa-list"></i> Hasil Pencarian</h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>ID Transaksi</th>
                                                    <th>ID Pesanan</th>
                                                    <th>Nama Menu</th>
                                                    <th>Harga</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody id="hasil_cari">
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Keranjang Penjualan -->
                        <div class="col-sm-12">
                            <div class="card card-primary">
                                <div class="card-header bg-primary text-white">
                                    <h5><i class="fa fa-shopping-cart"></i> KASIR</h5>
                                </div>
                                <div class="card-body">
                                    <div id="keranjang" class="table-responsive">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>ID Transaksi</th>
                                                    <th>ID Pesanan</th>
                                                    <th>Nama Menu</th>
                                                    <th style="width:10%;">Jumlah</th>
                                                    <th style="width:20%;">Total</th>
                                                    <th>Bayar</th>
                                                    <th>Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody id="keranjang_body">
                                                <!-- Isi dari keranjang akan ditambahkan melalui JavaScript -->
                                            </tbody>
                                        </table>
                                    </div>
                                    <br />
                                    <br />
                                    <!-- Total and Payment Section -->
                                    <div id="kasirnya">
                                        <table class="table table-stripped">
                                            <!-- Your PHP logic for payment and printing -->
                                            <!-- Example below, replace with your PHP logic -->
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Include JavaScript libraries and scripts here -->
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <script>
     $(document).ready(function () {
    $('#cari').keyup(function () {
        var keyword = $(this).val();
        if (keyword.trim() !== '') {
            $.ajax({
                url: 'search_menu.php',
                type: 'POST',
                data: { cari: keyword },
                success: function (response) {
                    $('#hasil_cari').html(response);
                    // Tambahkan event listener untuk tombol tambah ke kasir
                    $('.tambah-ke-kasir').click(function () {
                        // Dapatkan data dari baris tempat tombol ditekan
                        var idPesanan = $(this).data('id-pesanan');
                        var idTransaksi = $(this).data('id-transaksi'); // Menambahkan ini
                        var namaMenu = $(this).data('nama');
                        var hargaMenu = $(this).data('harga');
                        // Tambahkan data ke bagian kasir
                        $('#keranjang_body').append('<tr>' +
                            '<td>' + idTransaksi + '</td>' + // Menambahkan ini
                            '<td>' + idPesanan + '</td>' +
                            '<td>' + namaMenu + '</td>' +
                            '<td><input type="number" name="jumlah" class="form-control"></td>' +
                            '<td>Rp. ' + hargaMenu + '</td>' +
                            '<td>' +
                            '<button type="submit" class="btn btn-warning">Update</button>' +
                            '</td>' +
                            '</tr>');
                    });
                }
            });
        } else {
            $('#hasil_cari').empty();
        }
    });
});


    </script>
</body>

</html>