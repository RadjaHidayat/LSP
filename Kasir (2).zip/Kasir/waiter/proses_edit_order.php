<?php
include '..\koneksi.php';

// Pastikan ID pesanan ada dalam URL
if(isset($_POST['id_pesanan'], $_POST['menu'], $_POST['jumlah'])) {
    // Sanitasi data yang diterima dari form
    $id_pesanan = $_POST['id_pesanan'];
    $id_menu = $_POST['menu'];
    $jumlah = $_POST['jumlah'];

    // Buat koneksi ke database
    $koneksi = new mysqli("localhost", "root", "", "restoran");

    // Periksa koneksi
    if ($koneksi->connect_error) {
        die("Koneksi gagal: " . $koneksi->connect_error);
    }

    // Buat query SQL untuk update data pesanan
    $query = "UPDATE pesanan SET id_menu=?, jumlah=? WHERE id_pesanan=?";
    $statement = $koneksi->prepare($query);

    // Bind parameter ke statement
    $statement->bind_param("iii", $id_menu, $jumlah, $id_pesanan);

    // Eksekusi statement
    if ($statement->execute()) {
        // Redirect kembali ke halaman utama setelah pengubahan berhasil
        header("Location: entriorder.php");
        exit();
    } else {
        echo "Error: " . $query . "<br>" . $koneksi->error;
    }

    // Tutup statement dan koneksi
    $statement->close();
    $koneksi->close();
} else {
    echo "Data tidak lengkap.";
}
?>
