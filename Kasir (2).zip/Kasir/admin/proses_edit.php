<?php
include '..\koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data yang dikirimkan melalui formulir
    $idPelanggan = $_POST['idPelanggan'];
    $nmPelanggan = $_POST['nmPelanggan'];
    $jk = $_POST['jk'];
    $no_hp = $_POST['no_hp'];
    $alamat = $_POST['alamat'];
    $no_meja = $_POST['no_meja'];

    // Membuka koneksi ke database
    $koneksi = mysqli_connect("localhost", "root", "", "restoran");

    // Mengecek apakah koneksi berhasil
    if (!$koneksi) {
        die("Koneksi ke database gagal: " . mysqli_connect_error());
    }

    // Query untuk melakukan update data pelanggan
    $query = "UPDATE pelanggan SET nmPelanggan='$nmPelanggan', jk='$jk', no_hp='$no_hp', alamat='$alamat', no_meja='$no_meja' WHERE idPelanggan='$idPelanggan'";

    // Eksekusi query
    if (mysqli_query($koneksi, $query)) {
        // Jika update berhasil, redirect ke halaman entripelanggan.php
        header("Location: entripelanggan.php");
        exit;
    } else {
        // Jika update gagal, tampilkan pesan error
        echo "Gagal mengupdate data pelanggan: " . mysqli_error($koneksi);
    }

    // Menutup koneksi database
    mysqli_close($koneksi);
} else {
    // Jika tidak ada data yang dikirim via POST, kembalikan pengguna ke halaman sebelumnya
    header("Location: entripelanggan.php");
    exit;
}
?>
