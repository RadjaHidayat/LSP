<?php
// Pastikan ID menu ada dalam URL
if(isset($_GET['id'])) {
    // Sanitasi ID menu
    $id_menu = $_GET['id'];

    // Buat koneksi ke database
    $koneksi = new mysqli("localhost", "root", "", "restoran");

    // Periksa koneksi
    if ($koneksi->connect_error) {
        die("Koneksi gagal: " . $koneksi->connect_error);
    }

    // Buat query SQL untuk menghapus data menu dari tabel
    $query = "DELETE FROM menu WHERE id_menu = ?";
    $statement = $koneksi->prepare($query);

    // Bind parameter ke statement
    $statement->bind_param("i", $id_menu);

    // Eksekusi statement
    if ($statement->execute()) {
        // Reset auto-increment setelah menghapus data
        $resetQuery = "ALTER TABLE menu AUTO_INCREMENT = 1";
        if ($koneksi->query($resetQuery) === TRUE) {
            // Redirect kembali ke halaman utama setelah penghapusan
            header("Location: entribarang.php"); // Ganti entribarang.php dengan halaman utama Anda
            exit();
        } else {
            echo "Error: " . $resetQuery . "<br>" . $koneksi->error;
        }
    } else {
        echo "Error: " . $query . "<br>" . $koneksi->error;
    }

    // Tutup statement dan koneksi
    $statement->close();
    $koneksi->close();
} else {
    echo "ID menu tidak ditemukan.";
}
?>
