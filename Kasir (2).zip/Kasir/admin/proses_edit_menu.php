<?php
include '..\koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data yang dikirimkan melalui formulir
    $id_menu = $_POST['id_menu'];
    $nama_menu = $_POST['nama_menu']; // Ubah dari namamenu menjadi nama_menu
    $harga = $_POST['harga'];

    // Membuka koneksi ke database
    $koneksi = mysqli_connect("localhost", "root", "", "restoran");

    // Mengecek apakah koneksi berhasil
    if (!$koneksi) {
        die("Koneksi ke database gagal: " . mysqli_connect_error());
    }

    // Query untuk melakukan update data menu
    $query = "UPDATE menu SET namamenu='$nama_menu', harga='$harga' WHERE id_menu='$id_menu'";

    // Eksekusi query
    if (mysqli_query($koneksi, $query)) {
        // Jika update berhasil, redirect ke halaman entribarang.php
        header("Location: entribarang.php");
        exit;
    } else {
        // Jika update gagal, tampilkan pesan error
        echo "Gagal mengupdate data menu: " . mysqli_error($koneksi);
    }

    // Menutup koneksi database
    mysqli_close($koneksi);
} else {
    // Jika tidak ada data yang dikirim via POST, kembalikan pengguna ke halaman sebelumnya
    header("Location: entribarang.php");
    exit;
}
?>
