<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Kasir Go - Tambah Menu</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        /* Additional Styles */
        .form-container {
            margin-top: 50px;
        }
        
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        .wrapper {
            display: flex;
            flex-direction: column;
            min-height: 100%;
        }
        .content {
            flex-grow: 1;
        }
        .footer {
            background-color: #f8f9fc;
            padding: 20px;
            text-align: center;
        }
    </style>
</head>

<body id="page-top">
    <?php include 'template/sidebar.php'; ?>
    <?php include 'template/navbar.php'; ?>

    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">
            <!-- Entry Header -->
            <div class="entry-header text-center">
                <h5>
                    Tambah Menu
                </h5> <!-- Menambahkan kelas text-center -->
            </div>
        </div>
    </div>


<!-- Form untuk Tambah Menu -->
<div class="container form-container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <form action="proses_tambah_menu.php" method="post">
                <div class="form-group">
                    <label for="nama_menu">Nama Menu</label>
                    <input type="text" class="form-control" id="nama_menu" name="nama_menu" required>
                </div>
                <div class="form-group">
                    <label for="harga">Harga</label>
                    <input type="text" class="form-control" id="harga" name="harga" required>
                </div>
                <button type="submit" class="btn btn-success">Tambah Menu</button>
                <a href="entribarang.php" class="btn btn-primary">Kembali</a> <!-- Tambahkan button kembali -->
            </form>
        </div>
    </div>
</div>


        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="text-center">
                    <span>Copyright &copy; 2024 Kasir Go - All rights reserved.</span>
                </div>
            </div>
        </footer>
    </div>

    <!-- Scroll to Top Button -->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>
</body>

</html>
