<?php


include '..\koneksi.php';

// Pastikan variabel $_GET['id'] telah didefinisikan dan tidak kosong
if(isset($_GET['id']) && !empty($_GET['id'])) {
    // Ambil ID Pelanggan dari URL
    $idPelanggan = $_GET['id'];

    // Membuka koneksi ke database
    $koneksi = mysqli_connect("localhost", "root", "", "restoran");

    // Mengecek apakah koneksi berhasil
    if (!$koneksi) {
        die("Koneksi ke database gagal: " . mysqli_connect_error());
    }

    // Query untuk mengambil data pelanggan berdasarkan ID
    $query = "SELECT * FROM pelanggan WHERE idPelanggan = $idPelanggan";
    $result = mysqli_query($koneksi, $query);

    // Periksa apakah query berhasil dieksekusi
    if ($result) {
        // Ambil data pelanggan
        $data = mysqli_fetch_assoc($result);

        // Masukkan data ke dalam variabel
        $nmPelanggan = $data['nmPelanggan'];
        $jk = $data['jk'];
        $no_hp = $data['no_hp'];
        $alamat = $data['alamat'];
        $no_meja = $data['no_meja'];
    } else {
        echo "Gagal mengambil data pelanggan: " . mysqli_error($koneksi);
    }

    // Menutup koneksi database
    mysqli_close($koneksi);
} else {
    echo "ID Pelanggan tidak ditemukan dalam URL.";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Kasir Go</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        /* Style khusus untuk tulisan "Tambah Meja" */
        .add-header {
            text-align: center;
            /* Pusatkan teks */
            font-size: 24px;
            /* Ukuran teks */
            margin-bottom: 20px;
            /* Jarak bawah */
        }
    </style>
</head>

<body id="page-top">
    <?php include 'template/sidebar.php'; ?>
    <?php include 'template/navbar.php'; ?>

    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">
            <!-- Penambahan gaya menggunakan kelas CSS -->
            <div class="add-header">
                Tambah Meja
            </div>

            <div class="container">
                <div class="row">
                    <div class="col-md-6 offset-md-3">
                        <form action="proses_edit.php" method="POST">
                            <input type="hidden" name="idPelanggan" value="<?php echo $idPelanggan; ?>">
                            <div class="form-group">
                                <label for="nmPelanggan">Nama Pelanggan</label>
                                <input type="text" class="form-control" id="nmPelanggan" name="nmPelanggan"
                                    value="<?php echo $nmPelanggan; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="jk">Jenis Kelamin</label>
                                <select class="form-control" id="jk" name="jk" required>
                                    <option value="laki-laki" <?php if ($jk == 'laki-laki')
                                        echo 'selected'; ?>>Laki-laki
                                    </option>
                                    <option value="perempuan" <?php if ($jk == 'perempuan')
                                        echo 'selected'; ?>>Perempuan
                                    </option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="no_hp">No. HP</label>
                                <input type="text" class="form-control" id="no_hp" name="no_hp"
                                    value="<?php echo $no_hp; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="alamat">Alamat</label>
                                <input type="text" class="form-control" id="alamat" name="alamat"
                                    value="<?php echo $alamat; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="no_meja">No. Meja</label>
                                <input type="text" class="form-control" id="no_meja" name="no_meja"
                                    value="<?php echo $no_meja; ?>" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                            <a href="entripelanggan.php" class="btn btn-secondary">Batal</a> <!-- Tambahkan button batal -->
                        </form>


                    </div>
                </div>
            </div>

            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="text-center">
                        <span>Copyright &copy; 2024 Kasir Go - All rights reserved.</span>
                    </div>
                </div>
            </footer>
        </div>

        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>
</body>

</html>